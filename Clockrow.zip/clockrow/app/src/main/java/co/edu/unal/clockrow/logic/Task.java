package co.edu.unal.clockrow.logic;

public class Task {

    private String name;
    private String description;

}
