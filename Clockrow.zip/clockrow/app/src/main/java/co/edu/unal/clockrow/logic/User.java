package co.edu.unal.clockrow.logic;

public class User {
}
